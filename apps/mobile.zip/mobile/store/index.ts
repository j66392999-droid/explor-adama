import { configureStore } from '@reduxjs/toolkit';
// Use feature-specific slices (newer organization under `store/slices`)
import authReducer from './slices/auth/auth.slice';
import cartReducer from './cartSlice';
import ordersReducer from './ordersSlice';
import blogReducer from './blogSlice';
import userReducer from './slices/user/user.slice';
import appReducer from './slices/app/app.slice';

export const store = configureStore({
  reducer: {
    app: appReducer,
    auth: authReducer,
    user: userReducer,
    cart: cartReducer,
    orders: ordersReducer,
    blog: blogReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export type AppStore = typeof store;