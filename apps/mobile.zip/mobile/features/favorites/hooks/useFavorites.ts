import { useCallback } from 'react';

export const useFavorites = () => {
  const isFavorite = useCallback((id: string, type: string) => {
    // Minimal implementation; replace with real store logic
    return false;
  }, []);

  const addToFavorites = useCallback(async (id: string, type: string) => {
    // Add to favorites logic
    return Promise.resolve();
  }, []);

  const removeFromFavorites = useCallback(async (id: string, type: string) => {
    // Remove from favorites logic
    return Promise.resolve();
  }, []);

  const isLoading = false;

  return { isFavorite, addToFavorites, removeFromFavorites, isLoading };
};

export default useFavorites;
