import { apiClient } from '../../../shared/services/api/client';
import { ApiResponse, PaginatedResponse } from '../../../shared/types/api.types';
import { HomeData, Place, Event, Recommendation } from '../types/home.types';

export const homeApi = {
  // Get home page data
  getHomeData: async (): Promise<HomeData> => {
    const response = await apiClient.get<ApiResponse<HomeData>>('/home');
    return response.data!.data as HomeData;
  },

  // Get personalized recommendations with pagination
  getRecommendations: async (
    page: number = 1,
    limit: number = 10
  ): Promise<PaginatedResponse<Recommendation>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<Recommendation>>>(
      '/home/recommendations',
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<Recommendation>;
  },

  // Get trending events with pagination
  getTrendingEvents: async (
    page: number = 1,
    limit: number = 20
  ): Promise<PaginatedResponse<Event>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<Event>>>(
      '/home/trending',
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<Event>;
  },

  // Get featured places with pagination
  getFeaturedPlaces: async (
    page: number = 1,
    limit: number = 15
  ): Promise<PaginatedResponse<Place>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<Place>>>(
      '/home/featured',
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<Place>;
  },

  // Get paginated search results
  search: async (
    query: string,
    page: number = 1,
    limit: number = 20
  ): Promise<PaginatedResponse<Place | Event | Recommendation>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<Place | Event | Recommendation>>>(
      '/home/search',
      { params: { q: query, page, limit } }
    );
    return response.data!.data as PaginatedResponse<Place | Event | Recommendation>;
  },

  // Get interactions history with pagination
  getInteractions: async (
    page: number = 1,
    limit: number = 50
  ): Promise<PaginatedResponse<{
    itemId: string;
    itemType: string;
    type: string;
    timestamp: Date;
    context?: any;
  }>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<{
      itemId: string;
      itemType: string;
      type: string;
      timestamp: Date;
      context?: any;
    }>>>(
      '/interactions',
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<{
      itemId: string;
      itemType: string;
      type: string;
      timestamp: Date;
      context?: any;
    }>;
  },

  // Record user interaction for ML
  recordInteraction: async (data: {
    itemId: string;
    itemType: string;
    type: string;
    context?: any;
  }): Promise<void> => {
    await apiClient.post('/interactions', data);
  },

  // Get similar items with pagination
  getSimilarItems: async (
    itemId: string,
    itemType: 'PLACE' | 'EVENT',
    page: number = 1,
    limit: number = 10
  ): Promise<PaginatedResponse<Place | Event>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<Place | Event>>>(
      `/home/similar/${itemType}/${itemId}`,
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<Place | Event>;
  },

  // Get recommended categories with pagination
  getRecommendedCategories: async (
    page: number = 1,
    limit: number = 10
  ): Promise<PaginatedResponse<{
    id: string;
    name: string;
    icon: string;
    recommendationCount: number;
  }>> => {
    const response = await apiClient.get<ApiResponse<PaginatedResponse<{
      id: string;
      name: string;
      icon: string;
      recommendationCount: number;
    }>>>(
      '/home/categories/recommended',
      { params: { page, limit } }
    );
    return response.data!.data as PaginatedResponse<{
      id: string;
      name: string;
      icon: string;
      recommendationCount: number;
    }>;
  },

  // Helper to get all items from paginated endpoints (auto-paginates through all pages)
  getAllItems: async <T>(
    endpoint: string,
    initialPage: number = 1,
    pageSize: number = 50
  ): Promise<T[]> => {
    let allItems: T[] = [];
    let currentPage = initialPage;
    let hasMore = true;

    while (hasMore) {
      const response = await apiClient.get<ApiResponse<PaginatedResponse<T>>>(
        endpoint,
        { params: { page: currentPage, limit: pageSize } }
      );
      
      const paginatedData = response.data!.data as PaginatedResponse<T>;
      allItems = [...allItems, ...paginatedData.data];
      
      hasMore = paginatedData.pagination.hasNext;
      currentPage++;
    }

    return allItems;
  },

  // Get all recommendations (auto-paginates)
  getAllRecommendations: async (): Promise<Recommendation[]> => {
    return homeApi.getAllItems<Recommendation>('/home/recommendations');
  },

  // Get all trending events (auto-paginates)
  getAllTrendingEvents: async (): Promise<Event[]> => {
    return homeApi.getAllItems<Event>('/home/trending');
  },

  // Get all featured places (auto-paginates)
  getAllFeaturedPlaces: async (): Promise<Place[]> => {
    return homeApi.getAllItems<Place>('/home/featured');
  },
};