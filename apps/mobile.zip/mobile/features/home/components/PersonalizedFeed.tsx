import React from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { Text } from '../../../components/ui/Typography/Text';
import { Button } from '../../../components/ui/Button';
import { Loading } from '../../../components/ui/Loading';
import { EmptyState } from '../../../components/feedback/EmptyState';
import { ErrorState } from '../../../components/feedback/ErrorState';
import { RecommendationCard } from './RecommendationCard';
import { Recommendation } from '../types/home.types';
import { useTheme } from '../../../shared/hooks/ui/useTheme';

export type FeedAction = Recommendation | { itemType: 'EXPLORE' | 'OTHER'; item?: Recommendation['item'] };

interface PersonalizedFeedProps {
  recommendations: Recommendation[];
  isLoading?: boolean;
  isRefreshing?: boolean;
  error?: string | null;
  onRefresh?: () => void;
  onRetry?: () => void;
  onItemPress: (item: FeedAction) => void;
  style?: any;
}

export const PersonalizedFeed: React.FC<PersonalizedFeedProps> = ({
  recommendations,
  isLoading = false,
  isRefreshing = false,
  error = null,
  onRefresh,
  onRetry,
  onItemPress,
  style,
}) => {
  const { colors } = useTheme();

  if (isLoading && recommendations.length === 0) {
    return <Loading message="Loading recommendations..." />;
  }

  if (error && recommendations.length === 0) {
    return (
      <ErrorState
        message={error}
        onRetry={onRetry}
        style={style}
      />
    );
  }

  if (recommendations.length === 0) {
    return (
      <EmptyState
        title="No recommendations yet"
        message="Explore more places and events to get personalized recommendations"
        icon="🎯"
        action={{
          label: "Explore Now",
          onPress: () => onItemPress({ itemType: 'EXPLORE' }),
        }}
        style={style}
      />
    );
  }

  return (
    <View style={[styles.container, style]}>
      <View style={styles.header}>
        <Text variant="small" style={styles.title}>
          For You
        </Text>
        <Text style={styles.subtitle}>
          Personalized recommendations based on your interests
        </Text>
      </View>

      <FlatList
        data={recommendations}
        renderItem={({ item }) => (
          <RecommendationCard
            recommendation={item}
            onPress={onItemPress}
            style={styles.recommendationCard}
          />
        )}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        refreshControl={
          onRefresh ? (
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          ) : undefined
        }
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  title: {
    marginBottom: 4,
  },
  subtitle: {
    opacity: 0.7,
    fontSize: 14,
  },
  listContent: {
    paddingBottom: 16,
  },
  recommendationCard: {
    marginBottom: 12,
    marginHorizontal: 8,
  },
});